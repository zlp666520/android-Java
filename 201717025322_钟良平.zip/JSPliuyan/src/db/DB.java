package db;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import model.LyTable;
import model.User;
public class DB {
	Connection ct;
	PreparedStatement pstmt;
	// �ڹ��캯���н��������ݿ�����ӣ������ڽ���DB�����ʱ������������ݿ�
	public DB(){
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
				ct=DriverManager.getConnection
				("jdbc:mysql://localhost:3306/score","root","123456");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// ����username��password��ѯ�û����鵽�ͷ��ظö���û�оͷ���null
	public User checkUser(String username,String password){
		try{
		pstmt=ct.prepareStatement("select * from t_user where userName=? and passwordtxt=?");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			ResultSet rs=pstmt.executeQuery();
			User user=new User();
			while(rs.next()){
				user.setId(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				return user;
			}
			return null;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	// ��ѯ������Ϣ������һ��ArrayList
	public ArrayList findLyInfo(){
		try{
			ArrayList al=new ArrayList();
			pstmt=ct.prepareStatement("select * from t_liuyan");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				LyTable ly=new LyTable();
				ly.setId(rs.getInt(1));
				ly.setUserId(rs.getInt(2));
				ly.setDate(rs.getDate(3));
				ly.setTitle(rs.getString(4));
				ly.setContent(rs.getString(5));
				al.add(ly);
			}
			return al;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	//���ݵõ���userId����ѯ���Ӧ���û���
	public String getUserName(int id){
		String truename = "";
		try{
			pstmt = ct.prepareStatement("select trueName from t_user where id = ?");
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				truename=rs.getString(1);
			}
			return truename;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	//����������Ϣ
	public boolean addInfo(LyTable ly){
		try{
			pstmt=ct.prepareStatement("insert into t_liuyan(userid,datetime,title,content1) values(?,?,?,?)");
			pstmt.setInt(1, ly.getUserId());
			pstmt.setDate(2, ly.getDate());
			pstmt.setString(3, ly.getTitle());
			pstmt.setString(4, ly.getContent());
			pstmt.executeUpdate();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	//�����û���������
	public boolean insertUser(String username,String truename,String pwd,int role){
		try{
			pstmt=ct.prepareStatement("insert into t_user(userName,trueName,passwordtxt,role) values(?,?,?,?)");
			pstmt.setString(1, username);
			pstmt.setString(2, truename);
			pstmt.setString(3, pwd);
			pstmt.setInt(4, role);
			pstmt.executeUpdate();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
}
